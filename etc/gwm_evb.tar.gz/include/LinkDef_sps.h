#ifdef __CLING__

#pragma link C++ struct DPPChannel+;
#pragma link C++ struct CoincEvent+;
#pragma link C++ struct ProcessedEvent+;

#endif
